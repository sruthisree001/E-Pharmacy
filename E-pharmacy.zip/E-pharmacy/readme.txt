Project name - Clone of the PharEasy Website
Project Members - Rohit Roy - fw19_1005;
project Members - Aditya Sharma-fw19_0860
project Members - Akash Kumar Gupta-fw19_0144
Project Members - Nilesh More - fw19_0664 
Project Members - Chetan - fw19_1009

Work Divided - 
Rohit Roy - Homepage sliding windows and css styling with search box;
Nilesh More - Order Medicine/Offer page;
Hemant Kumar - Health Care Products;
Aditya Kothari - RtPCR/Labtest;
Akash Kumar - Login/Signup;
Chetan - Cart and Cart functionality;
            


Submission DeadLine - 18 June;
